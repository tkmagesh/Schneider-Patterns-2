﻿using System;
using System.Linq;
using System.Text;

namespace RentalReport
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
